<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>WAROSON</title>
    <link rel="stylesheet" href="./assets/css/bootstrap.min.css">
    <link rel="stylesheet" href="./assets/css/style.css">
</head>
<body>
    
    <div class="container-fluid body">
      
        <div class="row  rowsito">
            <div class="col-4 login">
            <div class="col-7 contentLogin">

  <h1>LOGIN</h1>
<form action="controlador/login.php" method="Post">
    
    <div class="mb-3">
        <label for="exampleInputEmail1" class="form-label">Ingresa tu correo electronico</label>
        <input type="email" class="form-control" id="exampleInputEmail1" aria-describedby="emailHelp" name="email">
    </div>
    <div class="mb-3">
        <label for="exampleInputPassword1" class="form-label">Ingresa tu contraseña</label>
        <input type="password" class="form-control" id="exampleInputPassword1" name="pass">
    </div>
    <div id="emailHelp" class="form-text">Crea tu cuenta, Oprime el botoncito!! :o.</div>
    <button type="submit" class="btn btn-primary">Enviar</button>
        

  
</form> 
<br>
<form action="registrarse.php" method="Post">
<button type="submit" class="btn btn-primary boton">Registrate</button>
</form>


            </div>
            <div class="col-7 botones">

</div>
            </div>
          
        </div>
    </div>


<script src="/Actividad Juan Camilo/assets/alertifyjs/alertify.js"></script>
<script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>