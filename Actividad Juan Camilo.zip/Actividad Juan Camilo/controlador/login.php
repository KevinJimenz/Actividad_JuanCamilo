<?php



if (isset($_POST['email']) && !empty($_POST['email']) && isset($_POST['pass']) && !empty($_POST['pass'])) {


    require_once '../modelo/MySQL.php';
    $email = $_POST['email'];
    $pass = md5($_POST['pass']);

    $mysql = new MySQL();

    $mysql->conectar();



    $usuarios = $mysql->efectuarConsulta("SELECT actividadjuancamilo.usuarios.id_usuario ,
    actividadjuancamilo.usuarios.correo, actividadjuancamilo.usuarios.password FROM  actividadjuancamilo.usuarios where
    actividadjuancamilo.usuarios.correo= '" . $email . "' and  actividadjuancamilo.usuarios.password = '" . $pass . "' ");



    //se cuentan las filas de la consulta , por cada usuario que coincida es  una fila
    // si la consulta arroja 1 y es mayor a cero existe el usuario sino no
    $fila = mysqli_fetch_assoc($usuarios);


    if ($fila > 0) {
        //inicia sesion
        //session_star();
        //traiga el modelo 
        if (mysqli_num_rows($usuarios)) {
            session_start();

            require_once '../modelo/usuarios.php';

            $usuarios = new usuarios();

            $usuarios->setId($fila['id_usuario']);

            $_SESSION['usuario'] = $usuarios;

            $_SESSION['acceso'] = true;

            header("Location: ../agregarProducto.php");
        }
    } else {
        header("Location: ../index.php");
        $mysql->desconectar();
    }
} else {

    echo '<script type="text/javascript"> 
    alert("Correo o Contraseña incorrecta");
    window.location="../index.php";
</script> ';
    header("Location: ../index.php");
}
