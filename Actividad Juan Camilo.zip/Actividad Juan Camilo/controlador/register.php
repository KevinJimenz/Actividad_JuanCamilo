<?php

if(isset($_POST['correo']) && !empty($_POST['correo']) && 
isset($_POST['pass']) && !empty($_POST['pass']) && 
isset($_POST['estado']) && !empty($_POST['imagen']) )
{
    require_once '../modelo/MySQL.php';

    $correo = $_POST['correo'];
    $contrasena = md5($_POST['pass']);
    $estado = $_POST['estado'];
    
    $mysql = new MySQL();
    
    $mysql ->conectar();
    
    $validar = $mysql->efectuarConsulta("SELECT actividadjuancamilo.usuarios.correo,
    actividadjuancamilo.usuarios.password,
    actividadjuancamilo.usuarios.estado
    FROM actividadjuancamilo.usuarios WHERE actividadjuancamilo.usuarios.correo = '".$correo."' " );
    
    
    
    if(mysqli_num_rows($validar) > 0)
    {
        header("Location: ../registrarse.php");
    
    }else{
    
        
        $consulta = $mysql->efectuarConsulta("INSERT INTO actividadjuancamilo.usuarios (`id_usuario`,`correo`,`password`,`estado`) values('','".$correo."','".$contrasena."','".$estado."') ");
        $mysql -> desconectar();
        header("Location: ../index.php");
    }


}else
{
    //poner alerta 
    header("Location: ../registrarse.php");


}







